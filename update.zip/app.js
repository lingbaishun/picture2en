/**
 * 拍照识物学英语 - 主应用逻辑
 * 功能：拍照/选图 → AI识别英文单词 → 收藏 → 复习
 */

// ===== 云更新配置 =====
// 部署更新包后，把这里替换为你的 GitHub Pages 地址
// 例如: 'https://你的用户名.github.io/picture2en/'
const UPDATE_BASE_URL = 'https://lingbaishun.github.io/picture2en/';  // GitHub Pages 更新地址

// ===== 常用物品中文翻译映射 =====
const TRANSLATIONS = {
  'bucket': '桶/水桶', 'notebook': '笔记本', 'laptop': '笔记本电脑', 'mouse': '鼠标/老鼠', 'keyboard': '键盘',
  'monitor': '显示器', 'screen': '屏幕', 'phone': '手机', 'cellphone': '手机',
  'smartphone': '智能手机', 'tablet': '平板', 'remote control': '遥控器',
  'television': '电视', 'tv': '电视', 'camera': '相机', 'clock': '时钟',
  'watch': '手表', 'lamp': '台灯', 'desk': '书桌', 'chair': '椅子',
  'table': '桌子', 'bed': '床', 'couch': '沙发', 'sofa': '沙发',
  'pillow': '枕头', 'bookcase': '书柜', 'shelf': '架子', 'door': '门',
  'window': '窗户', 'curtain': '窗帘', 'carpet': '地毯', 'mirror': '镜子',
  'cup': '杯子', 'mug': '马克杯', 'bottle': '瓶子', 'water bottle': '水瓶',
  'glass': '玻璃杯', 'plate': '盘子', 'bowl': '碗', 'fork': '叉子',
  'knife': '刀', 'spoon': '勺子', 'chopsticks': '筷子', 'pot': '锅',
  'pan': '平底锅', 'kettle': '水壶', 'toaster': '烤面包机',
  'refrigerator': '冰箱', 'microwave': '微波炉', 'oven': '烤箱',
  'stove': '炉子', 'sink': '水槽', 'faucet': '水龙头',
  'apple': '苹果', 'banana': '香蕉', 'orange': '橙子', 'grape': '葡萄',
  'strawberry': '草莓', 'watermelon': '西瓜', 'pineapple': '菠萝',
  'lemon': '柠檬', 'peach': '桃子', 'pear': '梨', 'cherry': '樱桃',
  'tomato': '番茄', 'potato': '土豆', 'carrot': '胡萝卜', 'onion': '洋葱',
  'broccoli': '西兰花', 'corn': '玉米', 'mushroom': '蘑菇',
  'bread': '面包', 'cake': '蛋糕', 'pizza': '披萨', 'hamburger': '汉堡',
  'sandwich': '三明治', 'hotdog': '热狗', 'rice': '米饭', 'noodle': '面条',
  'egg': '鸡蛋', 'cheese': '奶酪', 'butter': '黄油', 'milk': '牛奶',
  'coffee': '咖啡', 'tea': '茶', 'juice': '果汁', 'beer': '啤酒', 'wine': '红酒',
  'dog': '狗', 'cat': '猫', 'bird': '鸟', 'fish': '鱼', 'rabbit': '兔子',
  'hamster': '仓鼠', 'turtle': '乌龟', 'goldfish': '金鱼',
  'car': '汽车', 'bus': '公交车', 'truck': '卡车', 'bicycle': '自行车',
  'motorcycle': '摩托车', 'train': '火车', 'airplane': '飞机', 'boat': '船',
  'shoe': '鞋子', 'sneaker': '运动鞋', 'boot': '靴子', 'sandal': '凉鞋',
  'hat': '帽子', 'cap': '棒球帽', 'shirt': '衬衫', 'dress': '连衣裙',
  'jacket': '夹克', 'coat': '外套', 'pants': '裤子', 'jeans': '牛仔裤',
  'sock': '袜子', 'glove': '手套', 'scarf': '围巾', 'tie': '领带',
  'bag': '包', 'backpack': '背包', 'handbag': '手提包', 'wallet': '钱包',
  'umbrella': '雨伞', 'sunglasses': '太阳镜', 'glasses': '眼镜',
  'pen': '钢笔', 'pencil': '铅笔', 'eraser': '橡皮', 'ruler': '尺子',
  'scissors': '剪刀', 'book': '书', 'newspaper': '报纸', 'magazine': '杂志',
  'envelope': '信封', 'key': '钥匙', 'lock': '锁', 'lighter': '打火机',
  'candle': '蜡烛', 'flower': '花', 'tree': '树', 'grass': '草',
  'mountain': '山', 'river': '河', 'ocean': '海洋', 'beach': '沙滩',
  'soccer ball': '足球', 'basketball': '篮球', 'tennis ball': '网球',
  'baseball': '棒球', 'guitar': '吉他', 'piano': '钢琴', 'drum': '鼓',
  'violin': '小提琴', 'teddy bear': '泰迪熊',
  'toothbrush': '牙刷', 'toothpaste': '牙膏', 'soap': '肥皂',
  'towel': '毛巾', 'comb': '梳子', 'hair dryer': '吹风机',
  'comic book': '漫画书', 'espresso': '浓缩咖啡', 'menu': '菜单',
  'web site': '网站', 'envelope': '信封', 'joystick': '游戏手柄',
  'cellular telephone': '手机', 'digital clock': '数字时钟',
  'analog clock': '模拟时钟', 'wall clock': '挂钟',
  'dining table': '餐桌', 'coffee table': '茶几',
  'running shoe': '跑鞋', 'tennis shoe': '网球鞋',
  'hand towel': '手巾', 'bath towel': '浴巾',
  'paper towel': '纸巾', 'toilet tissue': '卫生纸',
  'plastic bag': '塑料袋', 'shopping cart': '购物车',
  'traffic light': '红绿灯', 'street sign': '路牌',
  'fire hydrant': '消防栓', 'parking meter': '停车计时器',
  'vase': '花瓶', 'potpie': '肉饼', 'burrito': '墨西哥卷',
  'ice cream': '冰淇淋', 'chocolate': '巧克力',
  'pretzel': '椒盐饼干', 'bagel': '百吉饼',
  'espresso maker': '咖啡机', 'coffeepot': '咖啡壶',
  'dishwasher': '洗碗机', 'washing machine': '洗衣机',
  'iron': '熨斗', 'vacuum': '吸尘器',
  'electric fan': '电风扇', 'air conditioner': '空调',
  'space heater': '暖风机', 'radiator': '暖气片',
  'loudspeaker': '扬声器', 'microphone': '麦克风',
  'headphone': '耳机', 'iPod': '音乐播放器',
  'printer': '打印机', 'scanner': '扫描仪',
  'hard disk': '硬盘', 'USB': 'U盘',
  'power plug': '电源插头', 'extension cord': '延长线',
  'spotlight': '聚光灯', 'flashlight': '手电筒',
  'lantern': '灯笼', 'chandelier': '吊灯',
  'piggy bank': '储蓄罐', 'safe': '保险箱',
  'combination lock': '密码锁', 'padlock': '挂锁',
};

// ===== 全局状态 =====
let model = null;
let currentStream = null;
let facingMode = 'environment';
let currentRecognition = null;
let deleteTargetId = null;

// 复习状态
let reviewItems = [];
let reviewIndex = 0;
let reviewCorrect = 0;
let isFlipped = false;

// ===== IndexedDB 数据库 =====
class FavoritesDB {
  constructor() {
    this.dbName = 'Picture2EnDB';
    this.storeName = 'favorites';
    this.db = null;
  }

  async open() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => { this.db = request.result; resolve(); };
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('word', 'word', { unique: false });
          store.createIndex('timestamp', 'timestamp', { unique: false });
          store.createIndex('wrongCount', 'wrongCount', { unique: false });
        }
      };
    });
  }

  async add(item) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).add(item);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async getAll() {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, 'readonly');
      const request = tx.objectStore(this.storeName).getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async delete(id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async update(item) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).put(item);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

const db = new FavoritesDB();

// ===== 工具函数 =====
function $(id) { return document.getElementById(id); }

function showToast(msg) {
  const container = $('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function speak(text) {
  if (!('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = 'en-US';
  utter.rate = 0.85;
  speechSynthesis.speak(utter);
}

function getTranslation(word) {
  const lower = word.toLowerCase().trim();
  if (TRANSLATIONS[lower]) return TRANSLATIONS[lower];
  // 尝试匹配部分词
  for (const [key, val] of Object.entries(TRANSLATIONS)) {
    if (lower.includes(key) || key.includes(lower)) return val;
  }
  return '';
}

function cleanClassName(name) {
  // MobileNet 返回的 className 可能包含逗号分隔的多个名称
  return name.split(',')[0].trim();
}

function formatDate(ts) {
  const d = new Date(ts);
  const m = d.getMonth() + 1;
  const day = d.getDate();
  const h = d.getHours().toString().padStart(2, '0');
  const min = d.getMinutes().toString().padStart(2, '0');
  return `${m}月${day}日 ${h}:${min}`;
}

function getConfidenceLevel(prob) {
  if (prob >= 0.6) return { text: `高置信度 ${(prob * 100).toFixed(0)}%`, cls: 'confidence-high' };
  if (prob >= 0.3) return { text: `中置信度 ${(prob * 100).toFixed(0)}%`, cls: 'confidence-mid' };
  return { text: `低置信度 ${(prob * 100).toFixed(0)}%`, cls: 'confidence-low' };
}

// ===== 加载 AI 模型 =====
async function loadModel() {
  try {
    $('splashStatus').textContent = '正在加载 AI 识别模型...';
    // 从本地加载模型，完全离线可用
    // inputRange 必须显式指定：mobilenet 库只有在走 tfhub 默认地址时才会自动取 [0,1]，
    // 传了 modelUrl 时会退回 [-1,1]，与该模型的训练预处理不符，会导致识别结果明显变差
    model = await mobilenet.load({
      version: 2,
      alpha: 1.0,
      modelUrl: 'lib/model.json',
      inputRange: [0, 1]
    });
    $('splashStatus').textContent = '模型加载完成！';
    await db.open();
    setTimeout(initApp, 500);
  } catch (err) {
    console.error('模型加载失败:', err);
    $('splashStatus').textContent = '模型加载失败: ' + err.message;
  }
}

// ===== 初始化应用 =====
function initApp() {
  const splash = $('splash');
  const app = $('app');
  splash.classList.add('fade-out');
  setTimeout(() => {
    splash.style.display = 'none';
    app.classList.remove('hidden');
  }, 500);

  initNavigation();
  initCamera();
  initFavorites();
  initReview();
}

// ===== 导航切换 =====
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const titles = {
    cameraView: '拍照识物',
    favoritesView: '我的收藏',
    reviewView: '单词复习'
  };

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const viewId = item.dataset.view;
      navItems.forEach(n => n.classList.remove('active'));
      item.classList.add('active');

      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      $(viewId).classList.add('active');
      $('headerTitle').textContent = titles[viewId];

      if (viewId === 'favoritesView') renderFavorites();
      if (viewId === 'reviewView') prepareReviewStart();
    });
  });
}

// ===== 相机功能 =====
function initCamera() {
  const captureBtn = $('captureBtn');
  const fileInput = $('fileInput');
  const switchBtn = $('switchCameraBtn');
  const retakeBtn = $('retakeBtn');

  // 尝试开启摄像头
  startCamera();

  captureBtn.addEventListener('click', capturePhoto);
  fileInput.addEventListener('change', handleFileSelect);
  switchBtn.addEventListener('click', switchCamera);
  retakeBtn.addEventListener('click', resetCamera);
}

async function startCamera() {
  try {
    if (currentStream) {
      currentStream.getTracks().forEach(t => t.stop());
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode, width: { ideal: 1280 }, height: { ideal: 960 } },
      audio: false
    });
    currentStream = stream;
    const video = $('cameraPreview');
    video.srcObject = stream;
    $('cameraPlaceholder').classList.add('hidden');
    $('cameraOverlay').style.display = '';
  } catch (err) {
    console.log('相机不可用，请使用相册选图:', err);
    $('cameraPlaceholder').classList.remove('hidden');
    $('cameraOverlay').style.display = 'none';
  }
}

function switchCamera() {
  facingMode = facingMode === 'environment' ? 'user' : 'environment';
  startCamera();
}

function capturePhoto() {
  const video = $('cameraPreview');
  if (!video.srcObject) {
    // 没有摄像头，触发文件选择
    $('fileInput').click();
    return;
  }

  const canvas = $('cameraCanvas');
  // 按视频实际比例截取，保证所见即所得（与 object-fit: cover 显示一致）
  const crop = getCoverCrop(video);
  const outSize = 1024; // 统一输出方形，便于贴纸和识别

  // 取景框区域：居中正方形，默认占可视区域的 78%
  const frameRatio = 0.78;
  const side = crop.w * frameRatio;
  const sx = crop.x + (crop.w - side) / 2;
  const sy = crop.y + (crop.h - side) / 2;

  canvas.width = outSize;
  canvas.height = outSize;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, sx, sy, side, side, 0, 0, outSize, outSize);

  const dataURL = canvas.toDataURL('image/jpeg', 0.92);
  recognizeImage(dataURL, canvas);
}

// 计算 object-fit: cover 下视频真实显示的源区域
function getCoverCrop(video) {
  const vw = video.videoWidth, vh = video.videoHeight;
  const rect = video.getBoundingClientRect();
  const targetRatio = rect.width / rect.height;
  const sourceRatio = vw / vh;
  let x = 0, y = 0, w = vw, h = vh;
  if (sourceRatio > targetRatio) {
    // 视频更宽，左右裁剪
    w = vh * targetRatio;
    x = (vw - w) / 2;
  } else {
    // 视频更高，上下裁剪
    h = vw / targetRatio;
    y = (vh - h) / 2;
  }
  return { x, y, w, h };
}

function handleFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = new Image();
    img.onload = () => {
      const canvas = $('cameraCanvas');
      // 居中裁剪为正方形，与拍照路径保持一致
      const outSize = 1024;
      const side = Math.min(img.width, img.height);
      const sx = (img.width - side) / 2;
      const sy = (img.height - side) / 2;
      canvas.width = outSize;
      canvas.height = outSize;
      canvas.getContext('2d').drawImage(img, sx, sy, side, side, 0, 0, outSize, outSize);

      const dataURL = canvas.toDataURL('image/jpeg', 0.92);
      recognizeImage(dataURL, canvas);
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
  e.target.value = '';
}

// ===== 图像识别 =====
async function recognizeImage(dataURL, canvasOrImg) {
  // 显示加载状态
  const loadingEl = document.createElement('div');
  loadingEl.className = 'loading-overlay';
  loadingEl.innerHTML = '<div class="loading-spinner"></div><div class="loading-text">AI 正在识别中...</div>';
  document.body.appendChild(loadingEl);

  try {
    const predictions = await model.classify(canvasOrImg, 5);
    loadingEl.remove();

    if (!predictions || predictions.length === 0) {
      showToast('未能识别出物品，请换个角度再试');
      return;
    }

    const top = predictions[0];
    const word = cleanClassName(top.className);
    const translation = getTranslation(word);
    const conf = getConfidenceLevel(top.probability);

    currentRecognition = {
      word,
      translation,
      probability: top.probability,
      imageData: dataURL,
      alternatives: predictions.slice(1).map(p => ({
        word: cleanClassName(p.className),
        probability: p.probability
      }))
    };

    showResult(currentRecognition, conf);
  } catch (err) {
    loadingEl.remove();
    console.error('识别失败:', err);
    showToast('识别失败，请重试');
  }
}

function showResult(rec, conf) {
  // 隐藏相机区域，显示结果
  document.querySelector('.camera-container').style.display = 'none';
  document.querySelector('.camera-actions').style.display = 'none';

  const panel = $('resultPanel');
  panel.style.display = '';

  $('resultImage').src = rec.imageData;
  $('resultWord').textContent = rec.word;
  $('resultPhonetic').textContent = '';
  $('resultConfidence').textContent = conf.text;
  $('resultConfidence').className = 'result-confidence ' + conf.cls;

  const transEl = $('resultTranslations');
  transEl.textContent = rec.translation ? `中文：${rec.translation}` : '';

  // 自动朗读
  speak(rec.word);

  // 绑定朗读按钮
  $('speakBtn').onclick = () => speak(rec.word);

  // 收藏按钮
  $('favoriteBtn').onclick = () => addToFavorites(rec);

  // 生成例句和贴纸（异步，不阻塞结果展示）
  renderSentences(rec);
  renderSticker(rec);

  // 其他候选
  const altContainer = $('resultAlternatives');
  if (rec.alternatives && rec.alternatives.length > 0) {
    altContainer.style.display = '';
    altContainer.innerHTML = '<h4>其他可能的结果：</h4>';
    rec.alternatives.forEach(alt => {
      const tr = getTranslation(alt.word);
      const div = document.createElement('div');
      div.className = 'alt-item';
      div.innerHTML = `
        <span class="alt-name">${alt.word}${tr ? ` (${tr})` : ''}</span>
        <span class="alt-prob">${(alt.probability * 100).toFixed(1)}%</span>
      `;
      div.addEventListener('click', () => {
        // 切换到此候选结果
        currentRecognition.word = alt.word;
        currentRecognition.translation = getTranslation(alt.word);
        currentRecognition.probability = alt.probability;
        const newConf = getConfidenceLevel(alt.probability);
        showResult(currentRecognition, newConf);
      });
      altContainer.appendChild(div);
    });
  } else {
    altContainer.style.display = 'none';
  }
}

// ===== 例句渲染 =====
function renderSentences(rec) {
  const container = $('sentencesList');
  container.innerHTML = '';
  try {
    const sentences = generateSentences($('cameraCanvas'), rec.word);
    rec.sentences = sentences;
    sentences.forEach((s) => {
      const item = document.createElement('div');
      item.className = 'sentence-item';
      item.innerHTML = `
        <div class="sentence-play">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
          </svg>
        </div>
        <div class="sentence-body">
          <div class="sentence-en">${s.text}</div>
          <div class="sentence-cn">${s.cn}</div>
        </div>
      `;
      item.querySelector('.sentence-play').addEventListener('click', (e) => {
        e.stopPropagation();
        speak(s.text);
      });
      item.addEventListener('click', () => speak(s.text));
      container.appendChild(item);
    });
  } catch (err) {
    console.error('例句生成失败:', err);
    container.innerHTML = '<div class="sentence-cn">例句生成失败</div>';
  }
}

// ===== 贴纸渲染 =====
function renderSticker(rec) {
  const loading = $('stickerLoading');
  const img = $('stickerImage');
  const saveBtn = $('saveStickerBtn');
  loading.style.display = '';
  img.style.display = 'none';
  saveBtn.style.display = 'none';

  // 延迟执行，让 UI 先渲染
  setTimeout(() => {
    try {
      const dataURL = generateSticker($('cameraCanvas'), rec.word);
      rec.stickerData = dataURL;
      img.src = dataURL;
      img.style.display = '';
      loading.style.display = 'none';
      saveBtn.style.display = '';
      saveBtn.onclick = () => saveSticker(dataURL, rec.word);
    } catch (err) {
      console.error('贴纸生成失败:', err);
      loading.textContent = '贴纸生成失败';
    }
  }, 50);
}

// 保存贴纸到相册（通过共享/下载）
function saveSticker(dataURL, word) {
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = `${word}-贴纸.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast('贴纸已保存 ✓');
}

function resetCamera() {
  document.querySelector('.camera-container').style.display = '';
  document.querySelector('.camera-actions').style.display = '';
  $('resultPanel').style.display = 'none';
  currentRecognition = null;
  startCamera();
}

// ===== 收藏功能 =====
async function addToFavorites(rec) {
  try {
    const all = await db.getAll();
    // 检查是否已收藏
    const exists = all.find(f => f.word === rec.word);
    if (exists) {
      showToast('这个单词已经收藏过了');
      return;
    }

    const item = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      word: rec.word,
      translation: rec.translation,
      imageData: rec.imageData,
      probability: rec.probability,
      timestamp: Date.now(),
      wrongCount: 0,
      reviewCount: 0,
    };

    await db.add(item);
    showToast('已收藏 ✓');
    updateFavBadge();
  } catch (err) {
    console.error('收藏失败:', err);
    showToast('收藏失败');
  }
}

async function updateFavBadge() {
  const all = await db.getAll();
  const badge = $('favBadge');
  if (all.length > 0) {
    badge.style.display = '';
    badge.textContent = all.length;
  } else {
    badge.style.display = 'none';
  }
}

// ===== 收藏夹页面 =====
function initFavorites() {
  $('searchInput').addEventListener('input', renderFavorites);
  $('cancelDeleteBtn').addEventListener('click', () => $('deleteModal').style.display = 'none');
  $('confirmDeleteBtn').addEventListener('click', confirmDelete);
  updateFavBadge();
}

async function renderFavorites() {
  const keyword = $('searchInput').value.toLowerCase().trim();
  let items = await db.getAll();
  items.sort((a, b) => b.timestamp - a.timestamp);

  if (keyword) {
    items = items.filter(f =>
      f.word.toLowerCase().includes(keyword) ||
      (f.translation && f.translation.includes(keyword))
    );
  }

  const list = $('favoritesList');
  const empty = $('favoritesEmpty');
  const stats = $('favoritesStats');

  if (items.length === 0) {
    list.innerHTML = '';
    empty.style.display = keyword ? 'none' : '';
    stats.textContent = keyword ? '没有找到匹配的单词' : '';
    return;
  }

  empty.style.display = 'none';
  stats.textContent = `共 ${items.length} 个收藏`;

  list.innerHTML = items.map(item => `
    <div class="fav-card" data-id="${item.id}">
      <img class="fav-img" src="${item.imageData}" alt="${item.word}" loading="lazy">
      <div class="fav-info">
        <div class="fav-word">${item.word}</div>
        <div class="fav-translation">${item.translation || ''}</div>
        <div class="fav-date">${formatDate(item.timestamp)}${item.wrongCount > 0 ? ' · 易错词' : ''}</div>
      </div>
      <div class="fav-actions">
        <button class="fav-action-btn fav-speak" onclick="speak('${item.word.replace(/'/g, "\\'")}')">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
          </svg>
        </button>
        <button class="fav-action-btn fav-delete" onclick="requestDelete('${item.id}')">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
          </svg>
        </button>
      </div>
    </div>
  `).join('');
}

function requestDelete(id) {
  deleteTargetId = id;
  $('deleteModal').style.display = '';
}

async function confirmDelete() {
  if (!deleteTargetId) return;
  $('deleteModal').style.display = 'none';

  const card = document.querySelector(`.fav-card[data-id="${deleteTargetId}"]`);
  if (card) {
    card.classList.add('removing');
    setTimeout(async () => {
      await db.delete(deleteTargetId);
      deleteTargetId = null;
      renderFavorites();
      updateFavBadge();
      showToast('已删除');
    }, 300);
  } else {
    await db.delete(deleteTargetId);
    deleteTargetId = null;
    renderFavorites();
    updateFavBadge();
  }
}

// ===== 复习功能 =====
function initReview() {
  // 复习模式选择
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => startReview(btn.dataset.mode));
  });

  // 翻牌
  $('flashcard').addEventListener('click', flipCard);

  // 认识 / 不认识
  $('rightBtn').addEventListener('click', () => markReview(true));
  $('wrongBtn').addEventListener('click', () => markReview(false));

  // 再来一轮
  $('reviewAgainBtn').addEventListener('click', () => {
    $('reviewComplete').style.display = 'none';
    $('reviewStart').style.display = '';
    prepareReviewStart();
  });

  // 复习中朗读
  $('reviewSpeakBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    if (reviewItems[reviewIndex]) speak(reviewItems[reviewIndex].word);
  });
}

async function prepareReviewStart() {
  const items = await db.getAll();
  $('modeAllCount').textContent = `共 ${items.length} 个单词`;

  if (items.length === 0) {
    $('reviewStart').style.display = 'none';
    $('reviewContainer').style.display = 'none';
    $('reviewComplete').style.display = 'none';
    $('reviewEmpty').style.display = '';
  } else {
    $('reviewStart').style.display = '';
    $('reviewContainer').style.display = 'none';
    $('reviewComplete').style.display = 'none';
    $('reviewEmpty').style.display = 'none';
  }
}

async function startReview(mode) {
  let items = await db.getAll();
  if (items.length === 0) {
    showToast('没有可复习的内容');
    return;
  }

  switch (mode) {
    case 'all':
      reviewItems = shuffleArray([...items]);
      break;
    case 'random':
      reviewItems = shuffleArray([...items]).slice(0, 10);
      break;
    case 'weak':
      reviewItems = items.filter(i => i.wrongCount > 0);
      if (reviewItems.length === 0) {
        showToast('没有薄弱词汇，太棒了！');
        return;
      }
      reviewItems = shuffleArray(reviewItems);
      break;
  }

  reviewIndex = 0;
  reviewCorrect = 0;
  isFlipped = false;

  $('reviewStart').style.display = 'none';
  $('reviewEmpty').style.display = 'none';
  $('reviewComplete').style.display = 'none';
  $('reviewContainer').style.display = '';

  showReviewCard();
}

function showReviewCard() {
  const item = reviewItems[reviewIndex];
  if (!item) return;

  isFlipped = false;
  $('flashcardInner').classList.remove('flipped');

  $('reviewImage').src = item.imageData;
  $('reviewImageBack').src = item.imageData;
  $('reviewWord').textContent = item.word;
  $('reviewPhonetic').textContent = item.translation || '';

  const total = reviewItems.length;
  const progress = ((reviewIndex) / total) * 100;
  $('reviewProgress').style.width = progress + '%';
  $('reviewProgressText').textContent = `${reviewIndex + 1}/${total}`;
}

function flipCard() {
  if (isFlipped) return;
  isFlipped = true;
  $('flashcardInner').classList.add('flipped');
  speak(reviewItems[reviewIndex].word);
}

async function markReview(correct) {
  if (!isFlipped) {
    // 自动翻牌
    flipCard();
    return;
  }

  const item = reviewItems[reviewIndex];
  item.reviewCount = (item.reviewCount || 0) + 1;

  if (correct) {
    reviewCorrect++;
  } else {
    item.wrongCount = (item.wrongCount || 0) + 1;
  }

  await db.update(item);

  reviewIndex++;
  if (reviewIndex >= reviewItems.length) {
    finishReview();
  } else {
    showReviewCard();
  }
}

function finishReview() {
  $('reviewContainer').style.display = 'none';
  $('reviewComplete').style.display = '';

  const total = reviewItems.length;
  const pct = Math.round((reviewCorrect / total) * 100);
  $('reviewScore').innerHTML = `
    <p>本轮共复习 <strong>${total}</strong> 个单词</p>
    <p>认识 <strong style="color:#10B981">${reviewCorrect}</strong> 个，
       不认识 <strong style="color:#EF4444">${total - reviewCorrect}</strong> 个</p>
    <p>正确率：<strong>${pct}%</strong></p>
  `;
  $('reviewProgress').style.width = '100%';
}

function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// ===== PWA 安装提示 =====
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
});

// ===== Service Worker 注册（仅 Web 环境，原生 App 内无需） =====
if ('serviceWorker' in navigator && !window.Capacitor) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

// ===== 云更新模块 =====
// 用底层 nativePromise 直接调用原生插件，避免 JS 代理注册的不确定性
function getHotUpdatePlugin() {
  if (!window.Capacitor || typeof window.Capacitor.nativePromise !== 'function') return null;
  const cap = window.Capacitor;
  return {
    checkVersion: (opts) => cap.nativePromise('HotUpdate', 'checkVersion', opts),
    getCurrentVersion: (opts) => cap.nativePromise('HotUpdate', 'getCurrentVersion', opts || {}),
    downloadAndApply: (opts) => cap.nativePromise('HotUpdate', 'downloadAndApply', opts),
    resetToBuiltin: (opts) => cap.nativePromise('HotUpdate', 'resetToBuiltin', opts || {}),
  };
}

// 版本号比较：返回 1 表示 a 更新，-1 表示 b 更新，0 表示相同
function compareVersion(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const va = pa[i] || 0, vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

async function checkForUpdate() {
  const plugin = getHotUpdatePlugin();
  if (!plugin || !UPDATE_BASE_URL) return;  // 非原生环境或未配置地址，跳过

  try {
    const versionUrl = UPDATE_BASE_URL.replace(/\/$/, '') + '/version.json';
    const res = await plugin.checkVersion({ url: versionUrl });
    const remote = JSON.parse(res.json);
    if (!remote || !remote.version || !remote.url) return;

    // 获取当前版本
    let current = '1.0.0';
    try {
      const cur = await plugin.getCurrentVersion();
      current = cur.version || '1.0.0';
    } catch (e) {}

    if (compareVersion(remote.version, current) > 0) {
      showUpdateDialog(remote, plugin);
    }
  } catch (err) {
    console.log('检查更新跳过:', err);
  }
}

function showUpdateDialog(remote, plugin) {
  // 若已有弹窗则不重复
  if ($('updateModal') && $('updateModal').style.display !== 'none') return;

  let modal = $('updateModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'updateModal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal">
        <div class="update-icon">⬆️</div>
        <h3 id="updateTitle">发现新版本</h3>
        <p id="updateDesc"></p>
        <div class="update-progress" id="updateProgress" style="display:none;">
          <div class="progress-bar"><div class="progress-fill" id="updateProgressBar"></div></div>
          <p id="updateStatusText" style="margin-top:8px;">正在下载更新...</p>
        </div>
        <div class="modal-actions" id="updateActions">
          <button class="btn btn-secondary" id="updateLaterBtn">稍后</button>
          <button class="btn btn-primary" id="updateNowBtn">立即更新</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }

  $('updateTitle').textContent = `发现新版本 ${remote.version}`;
  $('updateDesc').textContent = remote.changelog || '有新版本可用，是否更新？';
  $('updateProgress').style.display = 'none';
  $('updateActions').style.display = '';
  modal.style.display = '';

  $('updateLaterBtn').onclick = () => { modal.style.display = 'none'; };
  $('updateNowBtn').onclick = () => {
    $('updateActions').style.display = 'none';
    $('updateProgress').style.display = '';
    $('updateStatusText').textContent = '正在下载更新包（约13MB）...';
    // 模拟进度（原生插件无进度回调，用文字提示）
    let pct = 0;
    const timer = setInterval(() => {
      pct = Math.min(pct + 5, 90);
      $('updateProgressBar').style.width = pct + '%';
    }, 400);

    plugin.downloadAndApply({
      url: remote.url,
      version: remote.version
    }).then(() => {
      clearInterval(timer);
      $('updateProgressBar').style.width = '100%';
      $('updateStatusText').textContent = '更新完成，正在重启...';
      // 页面会被 setServerBasePath 自动重载
    }).catch((err) => {
      clearInterval(timer);
      $('updateProgress').style.display = 'none';
      $('updateActions').style.display = '';
      showToast('更新失败: ' + (err.message || err));
    });
  };
}

// ===== 启动 =====
document.addEventListener('DOMContentLoaded', () => {
  loadModel();
  // 延迟检查更新，不阻塞应用启动
  setTimeout(checkForUpdate, 1500);
});
