/**
 * 云端 AI 模块 —— 所有业务逻辑在此（可通过热更新迭代，不需要重装 APK）
 *
 * 原生层只是"搬运工"：提供 key、转发 HTTP、播放音频。
 * 因此以下内容都可以随时改动并推送更新：
 * - prompt（识别指令）
 * - 模型名、token 上限
 * - 返回数据的解析逻辑
 * - TTS 参数（音色、格式）
 * - 新增功能（OCR 等）
 */

// ===== 配置（改这里即可，不用动原生代码）=====
const DEEPSEEK_API = 'https://api.deepseek.com';
const CHAT_MODEL = 'deepseek-flash';
const CHAT_EFFORT = 'low';
const CHAT_MAX_TOKENS = 6000;
const TTS_VOICE = 'stella';

// ===== 原生代理 =====
function getNativeProxy() {
  if (!window.Capacitor || typeof window.Capacitor.nativePromise !== 'function') return null;
  const cap = window.Capacitor;
  return {
    postJson:      (opts) => cap.nativePromise('CloudAI', 'postJson', opts),
    postBinary:    (opts) => cap.nativePromise('CloudAI', 'postBinary', opts),
    playAudioFile: (opts) => cap.nativePromise('CloudAI', 'playAudioFile', opts),
    stopAudio:     ()     => cap.nativePromise('CloudAI', 'stopAudio', {}),
    isConfigured:  ()     => cap.nativePromise('CloudAI', 'isConfigured', {}),
    getApiKey:     ()     => cap.nativePromise('CloudAI', 'getApiKey', {}),
    setApiKey:     (opts) => cap.nativePromise('CloudAI', 'setApiKey', opts),
  };
}

// ===== Web 版 Key 管理（浏览器环境，用户自行输入）=====
const WEB_KEY_STORAGE = 'p2e_deepseek_key';

function getWebApiKey() {
  try { return (localStorage.getItem(WEB_KEY_STORAGE) || '').trim(); } catch (e) { return ''; }
}

function setWebApiKey(key) {
  try { localStorage.setItem(WEB_KEY_STORAGE, (key || '').trim()); } catch (e) {}
}

// 浏览器直连官方接口会被 CORS 拦截，允许用户填自建转发地址
const WEB_BASE_STORAGE = 'p2e_api_base';

function getWebApiBase() {
  try {
    const v = (localStorage.getItem(WEB_BASE_STORAGE) || '').trim();
    return (v || DEEPSEEK_API).replace(/\/+$/, '');
  } catch (e) {
    return DEEPSEEK_API;
  }
}

function setWebApiBase(base) {
  try {
    const v = (base || '').trim().replace(/\/+$/, '');
    if (!v) { localStorage.removeItem(WEB_BASE_STORAGE); return; }
    // 只接受 http/https，避免被塞进 javascript: 之类的协议
    if (!/^https?:\/\/[^\s]+$/i.test(v)) return;
    localStorage.setItem(WEB_BASE_STORAGE, v);
  } catch (e) {}
}

// 当前运行环境是否为原生 App
function isNativeApp() {
  return !!(window.Capacitor && typeof window.Capacitor.nativePromise === 'function');
}

// 保持旧版 JS 兼容（app.js 里引用了 getCloudAI）
function getCloudAI() {
  const proxy = getNativeProxy();
  if (proxy) {
    return {
      recognize:    (opts) => recognizeWithCloud(opts.image),
      speakCloud:   (opts) => cloudTTS(opts.text, opts.voice),
      stopSpeak:    ()     => proxy.stopAudio(),
      isConfigured: ()     => proxy.isConfigured(),
      setApiKey:    (opts) => proxy.setApiKey(opts),
    };
  }
  // Web 版：无原生代理，用浏览器 fetch（需用户自填 key）
  return {
    recognize:    (opts) => recognizeWithCloud(opts.image),
    // Web 版不用云端 TTS，抛错让 app.js 回退到 Web Speech
    speakCloud:   () => Promise.reject(new Error('WEB_USE_SPEECH')),
    stopSpeak:    () => Promise.resolve(),
    isConfigured: () => Promise.resolve({ configured: !!getWebApiKey() }),
    setApiKey:    (opts) => {
      setWebApiKey(opts.key);
      // 留空表示恢复默认官方地址
      setWebApiBase((opts && opts.base) || '');
      return Promise.resolve();
    },
  };
}

// Web 版通用 JSON POST（浏览器 fetch）
async function webPostJson(url, body, timeout) {
  const key = getWebApiKey();
  if (!key) throw new Error('NO_KEY');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout || 60000);
  try {
    let resp;
    try {
      resp = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + key
        },
        body,
        signal: controller.signal
      });
    } catch (e) {
      // fetch 只在网络层失败时抛错（含跨域被拦截、超时中断）
      const aborted = e && e.name === 'AbortError';
      throw new Error(aborted ? 'TIMEOUT' : 'NETWORK_OR_CORS');
    }
    const text = await resp.text();
    if (!resp.ok) throw new Error('HTTP ' + resp.status + ': ' + text.slice(0, 200));
    return { data: text };
  } finally {
    clearTimeout(timer);
  }
}

// ===== 识别 Prompt（可热更新！）=====
function buildRecognizePrompt() {
  return `识别图中最主要的物品。只返回JSON，不要任何解释或markdown代码块：
{"word":"英文单词(小写,单数)","zh":"中文名","bbox":[x0,y0,x1,y1],
"polygon":[[x,y],[x,y]],"color":"主体颜色英文词","confidence":0~1,
"alternatives":[{"word":"备选英文","zh":"中文"}],
"sentences":[{"en":"例句","cn":"中文翻译"}]}
bbox为物体边界框的相对坐标(0~1)。
polygon为该物品的外轮廓多边形，相对坐标(0~1)，顺时针给出16-24个点，
必须紧贴物体真实边缘（含把手、提梁等突出部分），且不要包含周围其他物体。
sentences给4句简单实用的例句，分别用 This is / 颜色描述 / I have / Look at 句型。
alternatives给2个其他可能的识别结果。`;
}

// ===== 云端识别 =====
// 最近一次云端失败原因（供上层提示用户，例如浏览器跨域被拦截）
var cloudLastError = '';

async function recognizeWithCloud(dataURL) {
  const proxy = getNativeProxy();
  cloudLastError = '';
  // 原生走插件代理；Web 走浏览器 fetch（需用户自填 key）
  if (!proxy && !getWebApiKey()) {
    cloudLastError = 'NO_KEY';
    console.warn('未配置 API Key，使用离线');
    return null;
  }

  try {
    const body = JSON.stringify({
      model: CHAT_MODEL,
      effort: CHAT_EFFORT,
      max_tokens: CHAT_MAX_TOKENS,
      stream: false,
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: buildRecognizePrompt() },
          { type: 'image_url', image_url: {
            url: dataURL.startsWith('data:') ? dataURL : 'data:image/jpeg;base64,' + dataURL
          }}
        ]
      }]
    });

    // 原生固定官方地址；Web 允许用自建转发地址绕开浏览器的跨域限制
    const url = (proxy ? DEEPSEEK_API : getWebApiBase()) + '/chat/completions';
    const res = proxy
      ? await proxy.postJson({ url, body, timeout: 60000 })
      : await webPostJson(url, body, 60000);

    const root = JSON.parse(res.data);
    const text = root.choices && root.choices[0] && root.choices[0].message
      ? root.choices[0].message.content : '';
    const data = parseCloudJson(text);
    if (!data || !data.word) return null;

    const word = String(data.word).trim().toLowerCase();
    return {
      source: 'cloud',
      word,
      translation: String(data.zh || '').trim(),
      color: String(data.color || '').trim().toLowerCase(),
      bbox: normalizeBbox(data.bbox),
      polygon: normalizePolygon(data.polygon),
      probability: clamp01(data.confidence) ?? 0.9,
      sentences: Array.isArray(data.sentences)
        ? data.sentences.filter(s => s && s.en).slice(0, 4)
            .map(s => ({ text: String(s.en).trim(), cn: String(s.cn || '').trim() }))
        : [],
      alternatives: Array.isArray(data.alternatives)
        ? data.alternatives.filter(a => a && a.word).slice(0, 4)
            .map(a => ({ word: String(a.word).trim().toLowerCase(), zh: String(a.zh || '').trim(), probability: null }))
        : [],
    };
  } catch (err) {
    const msg = String((err && err.message) || err);
    cloudLastError = msg;
    if (msg.includes('NO_KEY')) console.warn('未配置 API Key，使用离线');
    else console.warn('云端识别失败:', msg);
    return null;
  }
}

// ===== 云端 TTS =====
async function cloudTTS(text, voice) {
  const proxy = getNativeProxy();
  // Web 端无法播放本地音频文件，交由上层回退 Web Speech
  if (!proxy) throw new Error('WEB_USE_SPEECH');

  const body = JSON.stringify({
    text,
    voice_id: voice || TTS_VOICE,
    format: 'wav',
    filter_markdown: true
  });

  // postBinary 内置缓存：同一文本不会重复请求
  const res = await proxy.postBinary({
    url: DEEPSEEK_API + '/v1/tools/tts',
    body,
    cacheKey: (voice || TTS_VOICE) + '|' + text,
    timeout: 45000
  });

  await proxy.playAudioFile({ path: res.path });
}

// ===== 工具函数 =====
function parseCloudJson(raw) {
  if (!raw) return null;
  let text = String(raw).trim();
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  const start = text.indexOf('{'), end = text.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(text.slice(start, end + 1)); }
  catch (e) { console.warn('解析失败:', e); return null; }
}

function clamp01(v) {
  const n = Number(v);
  return isFinite(n) ? Math.max(0, Math.min(1, n)) : null;
}

function normalizeBbox(bbox) {
  if (!Array.isArray(bbox) || bbox.length !== 4) return null;
  let [x0, y0, x1, y1] = bbox.map(clamp01);
  if ([x0, y0, x1, y1].some(v => v === null)) return null;
  if (x1 < x0) [x0, x1] = [x1, x0];
  if (y1 < y0) [y0, y1] = [y1, y0];
  if ((x1 - x0) < 0.05 || (y1 - y0) < 0.05) return null;
  return [x0, y0, x1, y1];
}

function normalizePolygon(poly) {
  if (!Array.isArray(poly) || poly.length < 3) return null;
  const pts = [];
  for (const p of poly) {
    if (!Array.isArray(p) || p.length < 2) continue;
    const x = clamp01(p[0]), y = clamp01(p[1]);
    if (x === null || y === null) continue;
    pts.push([x, y]);
  }
  if (pts.length < 3) return null;
  let area = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % pts.length];
    area += x1 * y2 - x2 * y1;
  }
  if (Math.abs(area / 2) < 0.01) return null;
  return pts;
}
