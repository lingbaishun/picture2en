/**
 * 云端 AI 识别模块（DeepSeek）
 * - 识别物品英文名、中文、颜色、位置框、例句，一次调用完成
 * - API Key 由原生层提供（构建时注入），不存放在本文件中
 * - 失败时由 app.js 自动回退到离线 MobileNet
 */

// 原生云端插件代理
function getCloudAI() {
  if (!window.Capacitor || typeof window.Capacitor.nativePromise !== 'function') return null;
  const cap = window.Capacitor;
  return {
    recognize: (opts) => cap.nativePromise('CloudAI', 'recognize', opts),
    speakCloud: (opts) => cap.nativePromise('CloudAI', 'speakCloud', opts),
    stopSpeak: () => cap.nativePromise('CloudAI', 'stopSpeak', {}),
    isConfigured: () => cap.nativePromise('CloudAI', 'isConfigured', {}),
    setApiKey: (opts) => cap.nativePromise('CloudAI', 'setApiKey', opts),
  };
}

// 从模型回复中提取 JSON（容错处理 markdown 包裹等情况）
function parseCloudJson(raw) {
  if (!raw) return null;
  let text = String(raw).trim();
  // 去掉 markdown 代码块
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  // 截取第一个完整的 JSON 对象
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(text.slice(start, end + 1));
  } catch (e) {
    console.warn('云端返回解析失败:', e, text.slice(0, 200));
    return null;
  }
}

function clamp01(v) {
  const n = Number(v);
  if (!isFinite(n)) return null;
  return Math.max(0, Math.min(1, n));
}

// 校验并规整 bbox
function normalizeBbox(bbox) {
  if (!Array.isArray(bbox) || bbox.length !== 4) return null;
  let [x0, y0, x1, y1] = bbox.map(clamp01);
  if ([x0, y0, x1, y1].some(v => v === null)) return null;
  if (x1 < x0) [x0, x1] = [x1, x0];
  if (y1 < y0) [y0, y1] = [y1, y0];
  // 面积过小视为无效
  if ((x1 - x0) < 0.05 || (y1 - y0) < 0.05) return null;
  return [x0, y0, x1, y1];
}

/**
 * 调用云端识别
 * @returns {Promise<object|null>} 识别结果，失败返回 null（交由调用方回退离线）
 */
async function recognizeWithCloud(dataURL) {
  const cloud = getCloudAI();
  if (!cloud) return null;

  try {
    const res = await cloud.recognize({ image: dataURL });
    const data = parseCloudJson(res && res.raw);
    if (!data || !data.word) return null;

    const word = String(data.word).trim().toLowerCase();
    const sentences = Array.isArray(data.sentences)
      ? data.sentences
          .filter(s => s && s.en)
          .slice(0, 4)
          .map(s => ({ text: String(s.en).trim(), cn: String(s.cn || '').trim() }))
      : [];

    const alternatives = Array.isArray(data.alternatives)
      ? data.alternatives
          .filter(a => a && a.word)
          .slice(0, 4)
          .map(a => ({
            word: String(a.word).trim().toLowerCase(),
            zh: String(a.zh || '').trim(),
            probability: null
          }))
      : [];

    return {
      source: 'cloud',
      word,
      translation: String(data.zh || '').trim(),
      color: String(data.color || '').trim().toLowerCase(),
      bbox: normalizeBbox(data.bbox),
      probability: clamp01(data.confidence) ?? 0.9,
      sentences,
      alternatives,
    };
  } catch (err) {
    const msg = String((err && err.message) || err);
    if (msg.includes('NO_KEY')) {
      console.warn('未配置云端 API Key，使用离线识别');
    } else {
      console.warn('云端识别失败，回退离线:', msg);
    }
    return null;
  }
}
