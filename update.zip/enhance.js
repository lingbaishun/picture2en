/**
 * 增强功能模块
 * 1. 物体抠图：MobileNet 卷积特征图定位物体 + 颜色精修边缘 → 贴纸
 * 2. 主色调提取 → 英文例句
 * 纯前端实现，复用已加载的 MobileNet，无需额外模型，离线可用
 */

// MobileNet v2 最后一层卷积特征（7x7x1280），语义信息最丰富
const FEATURE_LAYER = 'module_apply_default/MobilenetV2/Conv_1/Relu6';
// 分类器权重 [1,1,1280,1001]，用于生成类激活图（CAM）
const LOGITS_WEIGHTS = 'module/MobilenetV2/Logits/Conv2d_1c_1x1/weights';

// ===== 颜色工具 =====
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)); break;
      case g: h = ((b - r) / d + 2); break;
      case b: h = ((r - g) / d + 4); break;
    }
    h /= 6;
  }
  return { h: h * 360, s, l };
}

function colorName(r, g, b) {
  const { h, s, l } = rgbToHsl(r, g, b);
  if (l < 0.16) return 'black';
  if (s < 0.14) return l > 0.78 ? 'white' : l > 0.4 ? 'gray' : 'black';
  if (h >= 15 && h <= 45 && l < 0.5 && s > 0.3) return 'brown';
  if (h < 15 || h >= 345) return 'red';
  if (h < 45) return 'orange';
  if (h < 70) return 'yellow';
  if (h < 165) return 'green';
  if (h < 255) return 'blue';
  if (h < 290) return 'purple';
  if (h < 345) return 'pink';
  return 'red';
}

function colorNameZh(name) {
  const map = {
    red: '红色', orange: '橙色', yellow: '黄色', green: '绿色',
    blue: '蓝色', purple: '紫色', pink: '粉色', brown: '棕色',
    black: '黑色', white: '白色', gray: '灰色'
  };
  return map[name] || name;
}

// ===== 第一步：用 MobileNet 特征图生成物体显著性图 =====
/**
 * @returns Float32Array(size*size) 取值 0..1，越大越可能是主体
 */
function computeSaliency(sourceCanvas, size) {
  // 注意：app.js 用 let 声明 model，不会挂到 window 上，需直接引用标识符
  if (typeof tf === 'undefined' || typeof model === 'undefined' || !model || !model.model) return null;
  try {
    return tf.tidy(() => {
      // 预处理：缩放到 224 并归一化到 [0,1]（与模型训练一致）
      const img = tf.browser.fromPixels(sourceCanvas)
        .resizeBilinear([224, 224])
        .toFloat()
        .div(255)
        .expandDims(0);

      // 取中间卷积特征 [1,7,7,1280]
      const feat = model.model.execute(img, FEATURE_LAYER);
      const [, fh, fw, fc] = feat.shape;

      let salMap = null;
      // 优先用 CAM：按识别到的类别加权特征通道，只高亮真正的目标物体
      const wEntry = model.model.weights && model.model.weights[LOGITS_WEIGHTS];
      if (wEntry && wEntry[0]) {
        const W = wEntry[0].reshape([fc, 1001]);        // [1280,1001]
        const pooled = feat.mean([1, 2]).reshape([1, fc]); // 全局平均池化 [1,1280]
        const logits = pooled.matMul(W);                 // [1,1001]
        const classIdx = logits.argMax(1).dataSync()[0];
        const wc = W.slice([0, classIdx], [fc, 1]);      // [1280,1] 该类别的通道权重
        // CAM = 特征图按通道加权求和
        salMap = feat.reshape([fh * fw, fc]).matMul(wc).reshape([fh, fw]);
        salMap = salMap.relu(); // 只保留正向贡献
      } else {
        salMap = feat.mean(3).squeeze();
      }

      // 归一化到 0..1
      const mn = salMap.min(), mx = salMap.max();
      salMap = salMap.sub(mn).div(mx.sub(mn).add(1e-6));
      // 双线性上采样到目标尺寸
      const up = tf.image.resizeBilinear(
        salMap.expandDims(2).expandDims(0), [size, size], true
      ).squeeze();
      return up.dataSync().slice();
    });
  } catch (err) {
    console.warn('显著性计算失败，退回颜色分割:', err);
    return null;
  }
}

// ===== 第二步：结合颜色模型精修边缘 =====
function refineMask(imageData, saliency, size) {
  const data = imageData.data;
  const N = size * size;

  // 用显著性高/低的像素分别建立前景、背景颜色模型
  const sorted = Float32Array.from(saliency).sort();
  const hiThr = sorted[Math.floor(N * 0.80)]; // 前 20% 作为确定前景
  const loThr = sorted[Math.floor(N * 0.40)]; // 后 40% 作为确定背景

  let fr = 0, fg = 0, fb = 0, fn = 0;
  let br = 0, bg = 0, bb = 0, bn = 0;
  for (let i = 0; i < N; i++) {
    const j = i * 4;
    if (saliency[i] >= hiThr) { fr += data[j]; fg += data[j + 1]; fb += data[j + 2]; fn++; }
    else if (saliency[i] <= loThr) { br += data[j]; bg += data[j + 1]; bb += data[j + 2]; bn++; }
  }
  if (fn === 0 || bn === 0) return null;
  fr /= fn; fg /= fn; fb /= fn;
  br /= bn; bg /= bn; bb /= bn;

  // 每个像素：比较与前景/背景颜色的距离，并融合显著性先验与中心先验
  const score = new Float32Array(N);
  const cx = size / 2, cy = size / 2;
  const maxDist = Math.hypot(cx, cy);
  for (let i = 0; i < N; i++) {
    const j = i * 4;
    const r = data[j], g = data[j + 1], b = data[j + 2];
    const df = Math.hypot(r - fr, g - fg, b - fb);
    const db = Math.hypot(r - br, g - bg, b - bb);
    // 颜色归属度：靠近前景色→接近1
    const colorScore = db / (df + db + 1e-6);
    // 中心先验：主体通常在画面中间
    const x = i % size, y = (i / size) | 0;
    const centerScore = 1 - Math.hypot(x - cx, y - cy) / maxDist;
    // 融合（显著性为主）
    score[i] = 0.55 * saliency[i] + 0.3 * colorScore + 0.15 * centerScore;
  }

  // 自适应阈值（Otsu 简化版：用均值+部分标准差）
  let mean = 0;
  for (let i = 0; i < N; i++) mean += score[i];
  mean /= N;
  let variance = 0;
  for (let i = 0; i < N; i++) { const d = score[i] - mean; variance += d * d; }
  const std = Math.sqrt(variance / N);
  const threshold = mean + 0.15 * std;

  const mask = new Uint8Array(N);
  for (let i = 0; i < N; i++) mask[i] = score[i] > threshold ? 255 : 0;
  return mask;
}

// ===== 第三步：保留包含中心的最大连通域，去掉杂散区域 =====
function keepMainComponent(mask, size) {
  const N = size * size;
  const label = new Int32Array(N).fill(-1);
  const queue = new Int32Array(N);
  let best = -1, bestScore = -1;
  const cx = size / 2, cy = size / 2;

  let current = 0;
  for (let start = 0; start < N; start++) {
    if (!mask[start] || label[start] !== -1) continue;
    let head = 0, tail = 0;
    queue[tail++] = start;
    label[start] = current;
    let count = 0;
    let sumCenterBonus = 0;
    while (head < tail) {
      const idx = queue[head++];
      count++;
      const x = idx % size, y = (idx / size) | 0;
      // 越靠近中心权重越高
      sumCenterBonus += 1 - Math.hypot(x - cx, y - cy) / Math.hypot(cx, cy);
      if (x > 0 && mask[idx - 1] && label[idx - 1] === -1) { label[idx - 1] = current; queue[tail++] = idx - 1; }
      if (x < size - 1 && mask[idx + 1] && label[idx + 1] === -1) { label[idx + 1] = current; queue[tail++] = idx + 1; }
      if (y > 0 && mask[idx - size] && label[idx - size] === -1) { label[idx - size] = current; queue[tail++] = idx - size; }
      if (y < size - 1 && mask[idx + size] && label[idx + size] === -1) { label[idx + size] = current; queue[tail++] = idx + size; }
    }
    // 评分：面积 × 中心贴合度
    const score = count * (sumCenterBonus / count);
    if (score > bestScore) { bestScore = score; best = current; }
    current++;
  }

  if (best < 0) return mask;
  const out = new Uint8Array(N);
  for (let i = 0; i < N; i++) out[i] = label[i] === best ? 255 : 0;
  return out;
}

// ===== 形态学：闭运算填补空洞 + 开运算去毛刺 =====
function morph(mask, size, radius, dilateFirst) {
  const dilate = (m) => {
    const o = new Uint8Array(m.length);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      let on = 0;
      for (let dy = -radius; dy <= radius && !on; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          const nx = x + dx, ny = y + dy;
          if (nx >= 0 && nx < size && ny >= 0 && ny < size && m[ny * size + nx]) { on = 1; break; }
        }
      }
      o[y * size + x] = on ? 255 : 0;
    }
    return o;
  };
  const erode = (m) => {
    const o = new Uint8Array(m.length);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      let all = 1;
      for (let dy = -radius; dy <= radius && all; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || nx >= size || ny < 0 || ny >= size || !m[ny * size + nx]) { all = 0; break; }
        }
      }
      o[y * size + x] = all ? 255 : 0;
    }
    return o;
  };
  return dilateFirst ? erode(dilate(mask)) : dilate(erode(mask));
}

// 边缘羽化，让贴纸边缘自然
function featherMask(mask, size, radius) {
  const out = new Float32Array(mask.length);
  const r = radius;
  // 简单盒式模糊
  const tmp = new Float32Array(mask.length);
  for (let y = 0; y < size; y++) {
    let sum = 0;
    for (let x = -r; x <= r; x++) sum += mask[y * size + Math.min(size - 1, Math.max(0, x))];
    for (let x = 0; x < size; x++) {
      tmp[y * size + x] = sum / (2 * r + 1);
      const add = mask[y * size + Math.min(size - 1, x + r + 1)];
      const sub = mask[y * size + Math.max(0, x - r)];
      sum += add - sub;
    }
  }
  for (let x = 0; x < size; x++) {
    let sum = 0;
    for (let y = -r; y <= r; y++) sum += tmp[Math.min(size - 1, Math.max(0, y)) * size + x];
    for (let y = 0; y < size; y++) {
      out[y * size + x] = sum / (2 * r + 1);
      const add = tmp[Math.min(size - 1, y + r + 1) * size + x];
      const sub = tmp[Math.max(0, y - r) * size + x];
      sum += add - sub;
    }
  }
  return out;
}

// 纯颜色分割（无 TF 时的后备方案）
function fallbackColorMask(imageData, size) {
  const data = imageData.data;
  const N = size * size;
  let br = 0, bg = 0, bb = 0, n = 0;
  const step = Math.max(1, (size / 16) | 0);
  for (let x = 0; x < size; x += step) {
    for (const y of [0, size - 1]) { const j = (y * size + x) * 4; br += data[j]; bg += data[j + 1]; bb += data[j + 2]; n++; }
  }
  for (let y = 0; y < size; y += step) {
    for (const x of [0, size - 1]) { const j = (y * size + x) * 4; br += data[j]; bg += data[j + 1]; bb += data[j + 2]; n++; }
  }
  br /= n; bg /= n; bb /= n;
  const mask = new Uint8Array(N);
  for (let i = 0; i < N; i++) {
    const j = i * 4;
    const d = Math.hypot(data[j] - br, data[j + 1] - bg, data[j + 2] - bb);
    mask[i] = d > 60 ? 255 : 0;
  }
  return mask;
}

/**
 * 框内分割：已知物体在 bbox 内时使用
 * 思路：框外环带 = 确定背景，框中心区 = 确定前景，
 * 各自建立颜色直方图模型，再对框内每个像素做似然比判别。
 * 比全图统计准得多，能把桌面、墙面等背景从框内剔除。
 */
function segmentInsideBbox(imageData, size, bbox, saliency) {
  const data = imageData.data;
  const N = size * size;
  const [x0, y0, x1, y1] = bbox;
  const bx0 = Math.max(0, Math.floor(x0 * size));
  const by0 = Math.max(0, Math.floor(y0 * size));
  const bx1 = Math.min(size - 1, Math.ceil(x1 * size));
  const by1 = Math.min(size - 1, Math.ceil(y1 * size));
  const bw = bx1 - bx0, bh = by1 - by0;
  if (bw < 4 || bh < 4) return null;

  // 颜色直方图（每通道 4bit → 16*16*16 = 4096 bin），对光照变化更鲁棒
  const BIN = 16, BINS = BIN * BIN * BIN;
  const binOf = (i) => {
    const j = i * 4;
    return ((data[j] >> 4) * BIN + (data[j + 1] >> 4)) * BIN + (data[j + 2] >> 4);
  };

  const fgHist = new Float32Array(BINS);
  const bgHist = new Float32Array(BINS);
  let fgTotal = 0, bgTotal = 0;

  // 背景样本：框外一圈环带（宽度取框尺寸的 25%，至少 6px）
  const ring = Math.max(6, Math.round(Math.min(bw, bh) * 0.25));
  for (let y = Math.max(0, by0 - ring); y <= Math.min(size - 1, by1 + ring); y++) {
    for (let x = Math.max(0, bx0 - ring); x <= Math.min(size - 1, bx1 + ring); x++) {
      const inside = x >= bx0 && x <= bx1 && y >= by0 && y <= by1;
      if (inside) continue; // 只取框外
      bgHist[binOf(y * size + x)]++; bgTotal++;
    }
  }

  // 前景样本：框中心 50% 区域，并优先采纳显著性高的像素
  const cx0 = bx0 + bw * 0.25, cx1 = bx1 - bw * 0.25;
  const cy0 = by0 + bh * 0.25, cy1 = by1 - bh * 0.25;
  for (let y = Math.floor(cy0); y <= Math.ceil(cy1); y++) {
    for (let x = Math.floor(cx0); x <= Math.ceil(cx1); x++) {
      if (x < 0 || x >= size || y < 0 || y >= size) continue;
      const i = y * size + x;
      const weight = saliency ? (0.4 + saliency[i]) : 1;
      fgHist[binOf(i)] += weight; fgTotal += weight;
    }
  }
  if (fgTotal < 1 || bgTotal < 1) return null;

  // 归一化为概率
  for (let b = 0; b < BINS; b++) { fgHist[b] /= fgTotal; bgHist[b] /= bgTotal; }

  const mask = new Uint8Array(N);
  const eps = 1e-6;
  for (let y = by0; y <= by1; y++) {
    for (let x = bx0; x <= bx1; x++) {
      const i = y * size + x;
      const b = binOf(i);
      const pf = fgHist[b] + eps, pb = bgHist[b] + eps;
      // 颜色似然比 → 0..1
      let score = pf / (pf + pb);
      // 融合显著性与框内中心先验
      if (saliency) score = 0.65 * score + 0.35 * saliency[i];
      // 框内边缘略微降权，倾向把贴边像素判为背景
      const edgeX = Math.min(x - bx0, bx1 - x) / (bw / 2);
      const edgeY = Math.min(y - by0, by1 - y) / (bh / 2);
      const edgeFactor = Math.min(1, Math.min(edgeX, edgeY) * 3 + 0.35);
      mask[i] = (score * edgeFactor) > 0.5 ? 255 : 0;
    }
  }
  return mask;
}

// 由云端 bbox 生成先验图：框内高、框外急剧衰减
function bboxPrior(bbox, size) {
  const [x0, y0, x1, y1] = bbox;
  const px0 = x0 * size, py0 = y0 * size, px1 = x1 * size, py1 = y1 * size;
  const prior = new Float32Array(size * size);
  // 衰减尺度：框尺寸的 8%，让边缘有过渡而非硬切
  const falloff = Math.max(4, Math.min(px1 - px0, py1 - py0) * 0.08);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      // 到框的距离（框内为 0）
      const dx = Math.max(px0 - x, 0, x - px1);
      const dy = Math.max(py0 - y, 0, y - py1);
      const d = Math.hypot(dx, dy);
      prior[y * size + x] = d === 0 ? 1 : Math.exp(-(d * d) / (2 * falloff * falloff));
    }
  }
  return prior;
}

// ===== 主流程：生成物体遮罩 =====
// bbox（可选）来自云端识别，能大幅提升复杂背景下的抠图准确度
function buildObjectMask(sourceCanvas, size, bbox) {
  const work = document.createElement('canvas');
  work.width = size; work.height = size;
  const wctx = work.getContext('2d', { willReadFrequently: true });
  wctx.drawImage(sourceCanvas, 0, 0, size, size);
  const imgData = wctx.getImageData(0, 0, size, size);

  let saliency = computeSaliency(sourceCanvas, size);

  if (bbox) {
    // 有云端框：以框为主导，显著性仅作细节补充
    const prior = bboxPrior(bbox, size);
    if (saliency) {
      const merged = new Float32Array(saliency.length);
      for (let i = 0; i < merged.length; i++) {
        // 框外直接压制，框内结合显著性
        merged[i] = prior[i] * (0.45 + 0.55 * saliency[i]);
      }
      saliency = merged;
    } else {
      saliency = prior;
    }
  }

  // 有 bbox 时用框内专用分割（背景模型取自框外环带，判别更准）
  let mask = bbox
    ? segmentInsideBbox(imgData, size, bbox, saliency)
    : (saliency ? refineMask(imgData, saliency, size) : null);
  if (!mask) mask = fallbackColorMask(imgData, size);

  mask = morph(mask, size, 2, true);   // 闭运算：填补内部空洞
  mask = keepMainComponent(mask, size); // 只保留主体
  mask = morph(mask, size, 1, false);  // 开运算：去掉毛刺

  return { mask, imgData };
}

// ===== 提取主色调 =====
function extractDominantColor(imageData, mask) {
  const data = imageData.data;
  // 用「颜色名众数」而非 RGB 均值：
  // 白杯子里有棕色咖啡、背景有木桌时，取均值会得出"橙色"这种错误结论；
  // 按颜色名投票，占面积最大的白色才会正确胜出。
  const votes = Object.create(null);
  let total = 0;
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i]) continue;
    const j = i * 4;
    const name = colorName(data[j], data[j + 1], data[j + 2]);
    votes[name] = (votes[name] || 0) + 1;
    total++;
  }
  if (total === 0) return { name: 'gray', ratio: 0, confident: false };

  // 彩色适度加权（物体特征色通常是彩色），但不足以让少量杂色反超大面积主色
  const chromatic = new Set(['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink', 'brown']);
  let best = null, bestScore = -1;
  for (const name in votes) {
    const score = (votes[name] / total) * (chromatic.has(name) ? 1.2 : 1);
    if (score > bestScore) { bestScore = score; best = name; }
  }

  const ratio = votes[best] / total;
  // 占比门槛：没有可靠的物体框时，抠图常把背景（桌面、墙面）一起算进来，
  // 此时颜色投票不可信，宁可不说颜色也不要说错。
  return { name: best, ratio, confident: ratio >= 0.5 };
}

// ===== 生成英文例句 =====
// cloudRec（可选）：云端识别结果，优先使用其例句与颜色
function generateSentences(sourceCanvas, word, cloudRec) {
  // 云端已给出例句，直接采用（质量更高、更自然）
  if (cloudRec && Array.isArray(cloudRec.sentences) && cloudRec.sentences.length > 0) {
    return cloudRec.sentences;
  }

  let colorWord = null;
  let colorConfident = false;
  if (cloudRec && cloudRec.color) {
    colorWord = cloudRec.color;
    colorConfident = true;
  } else {
    try {
      const bbox = cloudRec && cloudRec.bbox;
      const { mask, imgData } = buildObjectMask(sourceCanvas, 160, bbox);
      const c = extractDominantColor(imgData, mask);
      colorWord = c.name;
      colorConfident = c.confident;
    } catch (e) {
      console.warn('主色调提取失败:', e);
    }
  }

  const w = word.toLowerCase();
  const article = /^[aeiou]/.test(w) ? 'an' : 'a';
  const zh = (cloudRec && cloudRec.translation)
    || (typeof getTranslation === 'function' && getTranslation(w))
    || w;

  // 颜色判断不可靠时，宁可不提颜色，也不要说出错误的事实
  const second = (colorWord && colorConfident)
    ? { text: `The ${w} is ${colorWord}.`, cn: `这个${zh}是${colorNameZh(colorWord)}的。` }
    : { text: `I can see ${article} ${w}.`, cn: `我看到一个${zh}。` };

  return [
    { text: `This is ${article} ${w}.`, cn: `这是一个${zh}。` },
    second,
    { text: `I have ${article} ${w}.`, cn: `我有一个${zh}。` },
    { text: `Look at ${article} ${w}!`, cn: `看这个${zh}！` }
  ];
}

// ===== 生成贴纸 =====
// bbox（可选）：云端返回的物体位置，用于精准抠图
function generateSticker(sourceCanvas, word, bbox) {
  const size = 420;
  const { mask, imgData } = buildObjectMask(sourceCanvas, size, bbox);

  // 计算主体包围盒，用于裁切居中放大
  let minX = size, minY = size, maxX = 0, maxY = 0, any = false;
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i]) continue;
    any = true;
    const x = i % size, y = (i / size) | 0;
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  if (!any) { minX = 0; minY = 0; maxX = size - 1; maxY = size - 1; }

  // 羽化的 alpha 通道
  const alpha = featherMask(mask, size, 1);

  // 抠出的主体（带 alpha）
  const cut = document.createElement('canvas');
  cut.width = size; cut.height = size;
  const cctx = cut.getContext('2d');
  const cutData = cctx.createImageData(size, size);
  for (let i = 0; i < mask.length; i++) {
    const j = i * 4;
    cutData.data[j] = imgData.data[j];
    cutData.data[j + 1] = imgData.data[j + 1];
    cutData.data[j + 2] = imgData.data[j + 2];
    cutData.data[j + 3] = Math.max(0, Math.min(255, Math.round(alpha[i])));
  }
  cctx.putImageData(cutData, 0, 0);

  // 白色描边：膨胀遮罩
  const outlineR = 7;
  const outlineMask = dilateOnly(mask, size, outlineR);
  const outlineAlpha = featherMask(outlineMask, size, 1);
  const outline = document.createElement('canvas');
  outline.width = size; outline.height = size;
  const octx = outline.getContext('2d');
  const oData = octx.createImageData(size, size);
  for (let i = 0; i < outlineMask.length; i++) {
    const j = i * 4;
    oData.data[j] = 255; oData.data[j + 1] = 255; oData.data[j + 2] = 255;
    oData.data[j + 3] = Math.max(0, Math.min(255, Math.round(outlineAlpha[i])));
  }
  octx.putImageData(oData, 0, 0);

  // 输出画布：主体裁切放大 + 标签
  const outW = 480, labelH = 108;
  const out = document.createElement('canvas');
  out.width = outW;
  out.height = outW + labelH;
  const ctx = out.getContext('2d');

  // 包围盒按比例放大填满画布（留边距）
  const pad = outlineR + 6;
  const bw = (maxX - minX) + pad * 2, bh = (maxY - minY) + pad * 2;
  const sx = Math.max(0, minX - pad), sy = Math.max(0, minY - pad);
  const sw = Math.min(size - sx, bw), sh = Math.min(size - sy, bh);
  const scale = Math.min((outW - 24) / sw, (outW - 24) / sh);
  const dw = sw * scale, dh = sh * scale;
  const dx = (outW - dw) / 2, dy = (outW - dh) / 2;

  ctx.drawImage(outline, sx, sy, sw, sh, dx, dy, dw, dh);
  ctx.drawImage(cut, sx, sy, sw, sh, dx, dy, dw, dh);

  // 标签：白底圆角 + 深色文字
  ctx.font = 'bold 52px -apple-system, "Segoe UI", Arial, sans-serif';
  const textW = ctx.measureText(word.toLowerCase()).width;
  const labelW = Math.min(outW - 30, textW + 72);
  const labelX = (outW - labelW) / 2;
  const labelY = outW - 4;

  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.12)';
  ctx.shadowBlur = 10;
  ctx.shadowOffsetY = 3;
  ctx.fillStyle = '#FFFFFF';
  roundRect(ctx, labelX, labelY, labelW, 80, 26);
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = '#2B3350';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(word.toLowerCase(), outW / 2, labelY + 42);

  return out.toDataURL('image/png');
}

function dilateOnly(mask, size, radius) {
  const o = new Uint8Array(mask.length);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    let on = 0;
    for (let dy = -radius; dy <= radius && !on; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < size && ny >= 0 && ny < size && mask[ny * size + nx]) { on = 1; break; }
      }
    }
    o[y * size + x] = on ? 255 : 0;
  }
  return o;
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
