/**
 * 增强功能模块
 * 1. 轻量背景移除（基于颜色种子填充）→ 生成贴纸（白边 + 英文标签）
 * 2. 提取物品主色调 → 生成英文例句
 * 全部纯 Canvas 实现，无需额外模型，离线可用
 */

// ===== 主色调提取 =====
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)); break;
      case g: h = ((b - r) / d + 2); break;
      case b: h = ((r - g) / d + 4); break;
    }
    h /= 6;
  }
  return { h: h * 360, s, l };
}

function colorName(r, g, b) {
  const { h, s, l } = rgbToHsl(r, g, b);
  if (l < 0.18) return 'black';
  if (s < 0.15) return l > 0.75 ? 'white' : l > 0.4 ? 'gray' : 'black';
  // 棕色：中等亮度 + 橙黄色相 + 中高饱和
  if (h >= 15 && h <= 45 && l < 0.5 && s > 0.35) return 'brown';
  if (h < 15 || h >= 345) return 'red';
  if (h < 45) return 'orange';
  if (h < 70) return 'yellow';
  if (h < 160) return 'green';
  if (h < 200) return 'blue';
  if (h < 255) return 'blue';
  if (h < 290) return 'purple';
  if (h < 345) return 'pink';
  return 'red';
}

// ===== 背景移除：从边界 flood fill 找背景 =====
function buildForegroundMask(imageData) {
  const data = imageData.data;
  const width = imageData.width, height = imageData.height;
  const N = width * height;

  // 四角采样背景色（取边缘若干点的平均）
  const samplePoints = [];
  const step = Math.max(1, Math.floor(width / 12));
  for (let x = 0; x < width; x += step) {
    samplePoints.push((0 * width + x), ((height - 1) * width + x));
  }
  for (let y = 0; y < height; y += step) {
    samplePoints.push((y * width + 0), (y * width + width - 1));
  }
  let br = 0, bg = 0, bb = 0;
  for (const p of samplePoints) {
    br += data[p * 4]; bg += data[p * 4 + 1]; bb += data[p * 4 + 2];
  }
  const n = samplePoints.length || 1;
  br /= n; bg /= n; bb /= n;

  // 背景容差：颜色距离阈值
  const tolerance = 62;

  const isBackground = new Uint8Array(N); // 1 = 背景
  const inQueue = new Uint8Array(N);      // 防止同一像素重复入队导致队列溢出
  const queue = new Int32Array(N);
  let head = 0, tail = 0;
  const enqueue = (idx) => {
    if (idx >= 0 && idx < N && !isBackground[idx] && !inQueue[idx]) {
      inQueue[idx] = 1;
      queue[tail++] = idx;
    }
  };
  // 所有边界像素入队
  for (let x = 0; x < width; x++) { enqueue(x); enqueue((height - 1) * width + x); }
  for (let y = 0; y < height; y++) { enqueue(y * width); enqueue(y * width + width - 1); }

  while (head < tail) {
    const idx = queue[head++];
    if (isBackground[idx]) continue;
    const i = idx * 4;
    const dr = data[i] - br, dg = data[i + 1] - bg, db = data[i + 2] - bb;
    if (dr * dr + dg * dg + db * db > tolerance * tolerance) continue; // 前景，不扩展
    isBackground[idx] = 1;
    const x = idx % width, y = (idx / width) | 0;
    if (x > 0) enqueue(idx - 1);
    if (x < width - 1) enqueue(idx + 1);
    if (y > 0) enqueue(idx - width);
    if (y < height - 1) enqueue(idx + width);
  }

  // 生成 alpha：前景=255，背景=0
  const mask = new Uint8Array(N);
  for (let i = 0; i < N; i++) mask[i] = isBackground[i] ? 0 : 255;
  return mask;
}

// 形态学膨胀（用于白色描边）
function dilateMask(mask, width, height, radius) {
  const out = new Uint8Array(mask.length);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let on = 0;
      outer:
      for (let dy = -radius; dy <= radius; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          const nx = x + dx, ny = y + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
            if (mask[ny * width + nx]) { on = 1; break outer; }
          }
        }
      }
      out[y * width + x] = on ? 255 : 0;
    }
  }
  return out;
}

// 提取主色调（仅统计前景、饱和度较高的像素）
function extractDominantColor(imageData, mask) {
  const data = imageData.data;
  let r = 0, g = 0, b = 0, count = 0;
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i]) continue;
    const j = i * 4;
    const rr = data[j], gg = data[j + 1], bb = data[j + 2];
    const { s, l } = rgbToHsl(rr, gg, bb);
    if (s > 0.18 && l > 0.12 && l < 0.9) { // 排除近灰、过暗过亮
      r += rr; g += gg; b += bb; count++;
    }
  }
  if (count === 0) return { r: 200, g: 150, b: 80, name: 'brown' };
  r = Math.round(r / count); g = Math.round(g / count); b = Math.round(b / count);
  return { r, g, b, name: colorName(r, g, b) };
}

/**
 * 生成英文例句（基于单词 + 主色调）
 */
function generateSentences(sourceCanvas, word) {
  const size = 240;
  const c = document.createElement('canvas');
  c.width = size; c.height = size;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(sourceCanvas, 0, 0, size, size);
  const imgData = ctx.getImageData(0, 0, size, size);
  const mask = buildForegroundMask(imgData);
  const color = extractDominantColor(imgData, mask);

  const w = word.toLowerCase();
  const article = /^[aeiou]/.test(w) ? 'an' : 'a';
  const sentences = [];

  // 基础句型
  sentences.push({ text: `This is ${article} ${w}.`, cn: `这是一个${getTranslation(w) || w}。` });
  // 颜色句型（示例：The bucket is orange）
  sentences.push({ text: `The ${w} is ${color.name}.`, cn: `这个${getTranslation(w) || w}是${colorNameZh(color.name)}的。` });
  // 拥有句型
  sentences.push({ text: `I have ${article} ${w}.`, cn: `我有一个${getTranslation(w) || w}。` });
  // 感叹句型
  sentences.push({ text: `Look at ${article} ${w}!`, cn: `看这个${getTranslation(w) || w}！` });

  return sentences;
}

function colorNameZh(name) {
  const map = {
    red: '红色', orange: '橙色', yellow: '黄色', green: '绿色',
    blue: '蓝色', purple: '紫色', pink: '粉色', brown: '棕色',
    black: '黑色', white: '白色', gray: '灰色'
  };
  return map[name] || name;
}

/**
 * 生成贴纸图片（抠图 + 白色描边 + 英文标签）
 * 返回 dataURL (PNG)
 */
function generateSticker(sourceCanvas, word) {
  const size = 480;
  const work = document.createElement('canvas');
  work.width = size; work.height = size;
  const wctx = work.getContext('2d', { willReadFrequently: true });
  wctx.drawImage(sourceCanvas, 0, 0, size, size);
  const imgData = wctx.getImageData(0, 0, size, size);

  const mask = buildForegroundMask(imgData);
  const outline = dilateMask(mask, size, size, 9);

  // 输出画布：上方物品 + 下方标签
  const pad = 24;
  const labelH = 110;
  const out = document.createElement('canvas');
  out.width = size;
  out.height = size + labelH;
  const ctx = out.getContext('2d');

  // 1) 白色描边（膨胀后的遮罩）
  const outlineImg = ctx.createImageData(size, size);
  for (let i = 0; i < outline.length; i++) {
    if (outline[i]) {
      outlineImg.data[i * 4] = 255;
      outlineImg.data[i * 4 + 1] = 255;
      outlineImg.data[i * 4 + 2] = 255;
      outlineImg.data[i * 4 + 3] = 255;
    }
  }
  const tmp = document.createElement('canvas');
  tmp.width = size; tmp.height = size;
  tmp.getContext('2d').putImageData(outlineImg, 0, 0);
  ctx.drawImage(tmp, 0, 0);

  // 2) 抠出的物品（应用前景遮罩）
  const fg = document.createElement('canvas');
  fg.width = size; fg.height = size;
  const fgctx = fg.getContext('2d');
  fgctx.putImageData(imgData, 0, 0);
  const fgData = fgctx.getImageData(0, 0, size, size);
  for (let i = 0; i < mask.length; i++) {
    fgData.data[i * 4 + 3] = mask[i];
  }
  fgctx.putImageData(fgData, 0, 0);
  ctx.drawImage(fg, 0, 0);

  // 3) 标签（圆角白底 + 深蓝灰文字）
  const labelY = size - 10;
  const labelW = Math.min(size - 40, word.length * 34 + 70);
  const labelX = (size - labelW) / 2;
  ctx.fillStyle = '#FFFFFF';
  ctx.strokeStyle = '#F0F0F0';
  ctx.lineWidth = 3;
  roundRect(ctx, labelX, labelY, labelW, 84, 24);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#2B3350';
  ctx.font = 'bold 54px -apple-system, Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(word.toLowerCase(), size / 2, labelY + 44);

  return out.toDataURL('image/png');
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
